meyveler = ["elma", "armut", "çilek", "kiraz"] 
in_meyve=input("meyve ismi giriniz")
if in_meyve in meyveler:
 print(in_meyve)


#gorev2
#birebir karşılaştırma büyüklük küçüklük önemli
parola = "PyThOn123"
karakter=input("karakter giriniz")

if karakter not in parola:
  print("yoktur")

