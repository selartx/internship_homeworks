isim="selva"
yas=19
boy=1.60
ogrenci_mi=True

dogum_yili=input("dogum yilinizi giriniz:")
print("isim:",isim)
print("yas:",yas)
print("boy:",boy)
print("ogrenci mi:",ogrenci_mi)
print("dogum yili:",dogum_yili)
print("yasiniz:",2025-int(dogum_yili))
#input string aldığından int eklemek gerekiyor
