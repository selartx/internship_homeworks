sayi=10
sayi+=5
sayi-=3
sayi*=2
sayi/=4
print(sayi)

#gorev 2
metin = "Python" 
metin+= " Programlama"

print(metin)